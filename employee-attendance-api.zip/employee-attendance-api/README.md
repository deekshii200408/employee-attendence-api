# Employee Attendance & Analytics API

A learning project using Python 3.11+, FastAPI, and MongoDB.

> **Important:** This is a starter implementation. Before submitting it for an assessment, compare route names, request/response schemas, business rules, and aggregation outputs against the official assignment kit and OpenAPI contract.

## Features

- Punch-in and punch-out with duplicate and sequence checks
- Manual attendance corrections with reason, editor, and audit snapshots
- Attendance listing with optional employee/date filters
- Daily, employee, and summary analytics using MongoDB aggregation pipelines
- Health endpoint and database indexes

## Requirements

- Python 3.11+
- MongoDB 6.0+
- Git

## Run locally

1. Create and activate a virtual environment:

   Windows:
   ```powershell
   py -3.11 -m venv .venv
   .venv\Scripts\Activate.ps1
   ```

   macOS/Linux:
   ```bash
   python3.11 -m venv .venv
   source .venv/bin/activate
   ```

2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Set the MongoDB connection string if needed.

   PowerShell:
   ```powershell
   $env:MONGODB_URI="mongodb://localhost:27017"
   ```

   macOS/Linux:
   ```bash
   export MONGODB_URI="mongodb://localhost:27017"
   ```

4. Start the API:

   ```bash
   uvicorn app.main:app --reload
   ```

5. Open `http://127.0.0.1:8000/docs` for interactive API documentation.

## Routes in this starter

- `GET /health`
- `POST /attendance/punch-in`
- `POST /attendance/punch-out`
- `GET /attendance`
- `POST /attendance/correct`
- `GET /attendance/{employee_id}/audit`
- `GET /analytics/daily`
- `GET /analytics/employee/{employee_id}`
- `GET /analytics/summary`

## Environment variables

- `MONGODB_URI`: MongoDB connection string (defaults to local MongoDB)
- `DATABASE_NAME`: database name (defaults to `employee_attendance`)

Never commit credentials, `.env` files, or production secrets.

## Known limitations to resolve before submission

- Endpoint paths and JSON schemas have not yet been checked against the employer's OpenAPI contract.
- Authentication/authorization for corrections is not implemented; `corrected_by` is only recorded as supplied input.
- Audit insertion and attendance update are separate writes, not a multi-document transaction.
- Business timezone and cross-midnight shift rules must be confirmed from the official problem statement.
- Add tests and verify aggregation outputs against the provided sample data.
