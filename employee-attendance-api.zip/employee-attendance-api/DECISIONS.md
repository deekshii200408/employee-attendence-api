# Design Decisions

## 1. FastAPI

FastAPI provides typed request validation, clear HTTP error handling, and generated interactive API documentation. It is suitable for a small JSON API.

## 2. PyMongo

PyMongo is used as the MongoDB driver. The assignment emphasizes MongoDB aggregation pipelines, so analytics are calculated by MongoDB rather than loading all attendance documents into Python.

## 3. Attendance record shape

The starter stores one document per employee per calendar date, with `employee_id`, `date`, `punch_in`, `punch_out`, and timestamps. A unique compound index on `(employee_id, date)` helps enforce this model.

This decision must be checked against the assignment's official data model. If the provided model represents multiple shifts or cross-midnight sessions differently, follow that model instead.

## 4. UTC timestamps

Timestamps are created in UTC to avoid ambiguity. The business timezone and how attendance dates are assigned must be confirmed from the official requirements. Local business dates should not be inferred from UTC without an explicit rule.

## 5. Manual corrections and audit history

A correction requires a reason and the identity of the person making it. Before updating the attendance record, the API stores old and new values in an audit collection. In a production system, use authentication to establish the editor identity and consider a MongoDB transaction to keep the audit entry and update atomic.

## 6. Analytics aggregation

The daily, employee, and summary endpoints use aggregation stages such as `$match`, `$group`, and `$project`. Date filtering is applied before grouping to reduce the number of documents processed.

## 7. Indexes

Indexes support employee/date lookups and audit-history queries. The unique employee/date index also helps prevent duplicate daily attendance records.

## 8. Error handling

The API uses HTTP 4xx responses for invalid requests or attendance state conflicts, and HTTP 503 when MongoDB is unavailable. The exact response codes and schemas should match the provided OpenAPI contract.

## 9. Known trade-offs

- Authentication and authorization are not implemented in this starter.
- Audit writes and attendance updates are not transactional.
- Business-specific rules, route schemas, and exact analytics outputs still need validation against the assignment kit.
