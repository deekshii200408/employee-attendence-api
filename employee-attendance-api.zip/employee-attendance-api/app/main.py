"""
Employee Attendance & Analytics API
A learning-oriented FastAPI + MongoDB implementation.

Before submitting, compare every route and response with the assignment's
provided OpenAPI contract and problem statement.
"""
import os
from datetime import datetime, timezone
from typing import Optional

from bson import ObjectId
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field, ConfigDict
from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.errors import PyMongoError

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
DATABASE_NAME = os.getenv("DATABASE_NAME", "employee_attendance")

client = MongoClient(MONGODB_URI, serverSelectionTimeoutMS=3000)
db = client[DATABASE_NAME]
attendance = db["attendance"]
audit_logs = db["audit_logs"]

app = FastAPI(
    title="Employee Attendance & Analytics API",
    version="1.0.0",
    description="Attendance punch records, audited corrections, and analytics.",
)


class PunchRequest(BaseModel):
    employee_id: str = Field(min_length=1, max_length=100)


class CorrectionRequest(BaseModel):
    employee_id: str = Field(min_length=1, max_length=100)
    date: str = Field(description="Attendance date in YYYY-MM-DD format")
    punch_in: Optional[datetime] = None
    punch_out: Optional[datetime] = None
    reason: str = Field(min_length=3, max_length=500)
    corrected_by: str = Field(min_length=1, max_length=100)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def parse_day(day: str) -> datetime:
    try:
        return datetime.strptime(day, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError:
        raise HTTPException(status_code=422, detail="date must use YYYY-MM-DD")


def serialize(document: dict) -> dict:
    """Convert MongoDB ObjectId and datetimes into JSON-friendly values."""
    result = dict(document)
    result["id"] = str(result.pop("_id"))
    for key, value in result.items():
        if isinstance(value, datetime):
            result[key] = value.isoformat()
    return result


@app.on_event("startup")
def create_indexes():
    # Unique employee/day record supports one attendance document per employee per day.
    attendance.create_index(
        [("employee_id", ASCENDING), ("date", ASCENDING)], unique=True
    )
    attendance.create_index([("date", DESCENDING)])
    audit_logs.create_index([("attendance_id", ASCENDING), ("changed_at", DESCENDING)])


@app.get("/health")
def health():
    try:
        client.admin.command("ping")
        return {"status": "ok", "database": "connected"}
    except PyMongoError:
        raise HTTPException(status_code=503, detail="MongoDB is unavailable")


@app.post("/attendance/punch-in", status_code=201)
def punch_in(request: PunchRequest):
    now = utc_now()
    day = now.strftime("%Y-%m-%d")
    try:
        existing = attendance.find_one(
            {"employee_id": request.employee_id, "date": day}
        )
        if existing:
            if existing.get("punch_in") is not None:
                raise HTTPException(status_code=409, detail="Already punched in today")
            attendance.update_one(
                {"_id": existing["_id"]},
                {"$set": {"punch_in": now, "updated_at": now}},
            )
            updated = attendance.find_one({"_id": existing["_id"]})
            return serialize(updated)

        document = {
            "employee_id": request.employee_id,
            "date": day,
            "punch_in": now,
            "punch_out": None,
            "created_at": now,
            "updated_at": now,
        }
        result = attendance.insert_one(document)
        return serialize(attendance.find_one({"_id": result.inserted_id}))
    except HTTPException:
        raise
    except PyMongoError as exc:
        # A concurrent duplicate insert can hit the unique index.
        if exc.__class__.__name__ == "DuplicateKeyError":
            raise HTTPException(status_code=409, detail="Attendance already exists today")
        raise HTTPException(status_code=503, detail="Database operation failed")


@app.post("/attendance/punch-out")
def punch_out(request: PunchRequest):
    now = utc_now()
    day = now.strftime("%Y-%m-%d")
    record = attendance.find_one({"employee_id": request.employee_id, "date": day})
    if not record or record.get("punch_in") is None:
        raise HTTPException(status_code=409, detail="Punch in before punching out")
    if record.get("punch_out") is not None:
        raise HTTPException(status_code=409, detail="Already punched out today")
    if now < record["punch_in"]:
        raise HTTPException(status_code=409, detail="Punch-out cannot precede punch-in")

    attendance.update_one(
        {"_id": record["_id"], "punch_out": None},
        {"$set": {"punch_out": now, "updated_at": now}},
    )
    updated = attendance.find_one({"_id": record["_id"]})
    return serialize(updated)


@app.get("/attendance")
def list_attendance(
    employee_id: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: int = Query(default=100, ge=1, le=500),
):
    filters = {}
    if employee_id:
        filters["employee_id"] = employee_id
    if start_date or end_date:
        date_filter = {}
        if start_date:
            parse_day(start_date)
            date_filter["$gte"] = start_date
        if end_date:
            parse_day(end_date)
            date_filter["$lte"] = end_date
        filters["date"] = date_filter
    records = attendance.find(filters).sort("date", DESCENDING).limit(limit)
    return {"items": [serialize(item) for item in records], "count": attendance.count_documents(filters)}


@app.post("/attendance/correct")
def correct_attendance(request: CorrectionRequest):
    parse_day(request.date)
    record = attendance.find_one(
        {"employee_id": request.employee_id, "date": request.date}
    )
    if not record:
        raise HTTPException(status_code=404, detail="Attendance record not found")

    old_values = {
        "punch_in": record.get("punch_in"),
        "punch_out": record.get("punch_out"),
    }
    new_values = {
        "punch_in": request.punch_in,
        "punch_out": request.punch_out,
    }
    effective_in = request.punch_in if request.punch_in is not None else record.get("punch_in")
    effective_out = request.punch_out if request.punch_out is not None else record.get("punch_out")
    if effective_in and effective_out and effective_out < effective_in:
        raise HTTPException(status_code=422, detail="Punch-out cannot precede punch-in")

    changed_at = utc_now()
    updates = {"updated_at": changed_at}
    if request.punch_in is not None:
        updates["punch_in"] = request.punch_in
    if request.punch_out is not None:
        updates["punch_out"] = request.punch_out

    # Store an audit snapshot before applying the correction.
    audit_logs.insert_one({
        "attendance_id": record["_id"],
        "employee_id": request.employee_id,
        "date": request.date,
        "old_values": old_values,
        "new_values": {k: updates[k] for k in ("punch_in", "punch_out") if k in updates},
        "reason": request.reason,
        "corrected_by": request.corrected_by,
        "changed_at": changed_at,
    })
    attendance.update_one({"_id": record["_id"]}, {"$set": updates})
    return serialize(attendance.find_one({"_id": record["_id"]}))


@app.get("/attendance/{employee_id}/audit")
def attendance_audit(employee_id: str, date: Optional[str] = None):
    filters = {"employee_id": employee_id}
    if date:
        parse_day(date)
        filters["date"] = date
    logs = audit_logs.find(filters).sort("changed_at", DESCENDING).limit(200)
    return {"items": [serialize(item) for item in logs]}


@app.get("/analytics/daily")
def daily_analytics(
    start_date: str = Query(..., description="YYYY-MM-DD"),
    end_date: str = Query(..., description="YYYY-MM-DD"),
):
    parse_day(start_date)
    parse_day(end_date)
    if start_date > end_date:
        raise HTTPException(status_code=422, detail="start_date must be <= end_date")
    pipeline = [
        {"$match": {"date": {"$gte": start_date, "$lte": end_date}}},
        {"$group": {
            "_id": "$date",
            "employees_present": {"$sum": 1},
            "completed_sessions": {
                "$sum": {"$cond": [{"$and": [
                    {"$ne": ["$punch_in", None]},
                    {"$ne": ["$punch_out", None]},
                ]}, 1, 0]}
            },
        }},
        {"$project": {
            "_id": 0,
            "date": "$_id",
            "employees_present": 1,
            "completed_sessions": 1,
        }},
        {"$sort": {"date": 1}},
    ]
    return {"items": list(attendance.aggregate(pipeline))}


@app.get("/analytics/employee/{employee_id}")
def employee_analytics(
    employee_id: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
):
    filters = {"employee_id": employee_id}
    if start_date or end_date:
        date_filter = {}
        if start_date:
            parse_day(start_date)
            date_filter["$gte"] = start_date
        if end_date:
            parse_day(end_date)
            date_filter["$lte"] = end_date
        filters["date"] = date_filter
    pipeline = [
        {"$match": filters},
        {"$group": {
            "_id": "$employee_id",
            "days_recorded": {"$sum": 1},
            "completed_days": {"$sum": {"$cond": [
                {"$and": [
                    {"$ne": ["$punch_in", None]},
                    {"$ne": ["$punch_out", None]},
                ]}, 1, 0
            ]}},
            "total_seconds": {"$sum": {"$cond": [
                {"$and": [
                    {"$ne": ["$punch_in", None]},
                    {"$ne": ["$punch_out", None]},
                ]},
                {"$divide": [{"$subtract": ["$punch_out", "$punch_in"]}, 1000]},
                0
            ]}},
        }},
        {"$project": {
            "_id": 0,
            "employee_id": "$_id",
            "days_recorded": 1,
            "completed_days": 1,
            "total_hours": {"$round": [{"$divide": ["$total_seconds", 3600]}, 2]},
        }},
    ]
    result = list(attendance.aggregate(pipeline))
    return result[0] if result else {
        "employee_id": employee_id,
        "days_recorded": 0,
        "completed_days": 0,
        "total_hours": 0,
    }


@app.get("/analytics/summary")
def analytics_summary(
    start_date: str = Query(...),
    end_date: str = Query(...),
):
    parse_day(start_date)
    parse_day(end_date)
    if start_date > end_date:
        raise HTTPException(status_code=422, detail="start_date must be <= end_date")
    pipeline = [
        {"$match": {"date": {"$gte": start_date, "$lte": end_date}}},
        {"$group": {
            "_id": None,
            "total_records": {"$sum": 1},
            "unique_employees": {"$addToSet": "$employee_id"},
            "completed_sessions": {"$sum": {"$cond": [
                {"$and": [
                    {"$ne": ["$punch_in", None]},
                    {"$ne": ["$punch_out", None]},
                ]}, 1, 0
            ]}},
        }},
        {"$project": {
            "_id": 0,
            "total_records": 1,
            "unique_employees": {"$size": "$unique_employees"},
            "completed_sessions": 1,
        }},
    ]
    result = list(attendance.aggregate(pipeline))
    return result[0] if result else {
        "total_records": 0, "unique_employees": 0, "completed_sessions": 0
    }


@app.on_event("shutdown")
def close_mongo_connection():
    client.close()
